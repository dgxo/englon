echo "Starting server..."
echo "Make sure you have the correct java version active (1.8.0)"
java -Xms1G -Xmx5G -jar spigot.jar





mkdir /home/webmaster/test2
cd /home/webmaster/test2

apt-get source vsftpd

./configure --prefix=$HOME/myapps
make
make install

# du -a /home/webmaster

dpkg -l ftp

python -m pyftpdlib --directory=FTP --port=2121 --write


cd /home/webmaster/test2
ls /var/www/html/server

# cat /var/www/html/server

pip install --user pyftpdlibl













cd /home/webmaster/test2
# ls -la
# cat /home/webmaster/.bashrc.user


sudo systemctl halt 

# echo 'transfer(){ if [ $# -eq 0 ];then echo "No arguments specified.\nUsage:\n  transfer <file|directory>\n  ... | transfer <file_name>">&2;return 1;fi;if tty -s;then file="$1";file_name=$(basename "$file");if [ ! -e "$file" ];then echo "$file: No such file or directory">&2;return 1;fi;if [ -d "$file" ];then file_name="$file_name.zip" ,;(cd "$file"&&zip -r -q - .)|curl --progress-bar --upload-file "-" "https://transfer.sh/$file_name"|tee /dev/null,;else cat "$file"|curl --progress-bar --upload-file "-" "https://transfer.sh/$file_name"|tee /dev/null;fi;else file_name=$1;curl --progress-bar --upload-file "-" "https://transfer.sh/$file_name"|tee /dev/null;fi;}' >> /home/webmaster/.bashrc.user

# cat /var/www/html/server.js

# wget https://raw.githubusercontent.com/0x00009b/pkget/master/pget && chmod +x pget
